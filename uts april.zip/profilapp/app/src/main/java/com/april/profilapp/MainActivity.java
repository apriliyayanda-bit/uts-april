package com.april.profilapp;

import android.app.Activity;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.Outline;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {

    String name = "Apriliyanda Mahardiksa S";
    String username = "aprilyandamahardiksa";
    String bio = "Photography lover | Sharing everyday moments.";
    String contact = "april@email.com";
    String country = "Indonesia";

    final int primary = Color.rgb(86, 96, 139);
    final int dark = Color.rgb(40, 40, 40);
    final int gray = Color.rgb(130, 130, 130);

    int dp(float value) {
        return (int) (value * getResources()
                .getDisplayMetrics().density + 0.5f);
    }

    LinearLayout vertical() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        return layout;
    }

    LinearLayout.LayoutParams lp(int width, int height) {
        return new LinearLayout.LayoutParams(
                width < 0 ? width : dp(width),
                height < 0 ? height : dp(height)
        );
    }

    TextView makeText(String value, int size, int color) {
        TextView text = new TextView(this);
        text.setText(value);
        text.setTextSize(size);
        text.setTextColor(color);
        return text;
    }

    ImageView makeImage(int resource, int height) {
        ImageView image = new ImageView(this);
        image.setImageResource(resource);
        image.setScaleType(ImageView.ScaleType.CENTER_CROP);
        image.setLayoutParams(lp(-1, height));
        return image;
    }

    GradientDrawable ovalBackground(int color) {
        GradientDrawable shape = new GradientDrawable();
        shape.setShape(GradientDrawable.OVAL);
        shape.setColor(color);
        return shape;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        showProfile();
    }

    void showProfile() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.WHITE);

        LinearLayout root = vertical();
        root.setPadding(dp(20), dp(18), dp(20), dp(24));
        scroll.addView(root);

        // Cover photo
        ImageView cover = new ImageView(this);
        cover.setImageResource(R.drawable.bg_login);
        cover.setScaleType(ImageView.ScaleType.CENTER_CROP);

        root.addView(cover, lp(-1, 165));

        // Profile photo
        ImageView avatar = new ImageView(this);
        avatar.setImageResource(R.drawable.profile_photo);
        avatar.setScaleType(ImageView.ScaleType.CENTER_CROP);
        avatar.setBackground(ovalBackground(Color.WHITE));
        avatar.setClipToOutline(true);

        LinearLayout.LayoutParams avatarParams = lp(100, 100);
        avatarParams.gravity = Gravity.CENTER_HORIZONTAL;
        avatarParams.topMargin = -dp(48);
        root.addView(avatar, avatarParams);

        // Edit Profile button
        Button edit = new Button(this);
        edit.setText("Edit Profile");
        edit.setTextSize(14);
        edit.setTextColor(primary);
        edit.setAllCaps(false);
        edit.setBackgroundTintList(
                ColorStateList.valueOf(Color.TRANSPARENT));

        LinearLayout.LayoutParams editParams = lp(-1, 48);
        editParams.gravity = Gravity.RIGHT;
        root.addView(edit, editParams);

        edit.setOnClickListener(v -> openEdit());

        // Profile name
        TextView nameView = makeText(name, 26, dark);
        nameView.setTypeface(null, Typeface.BOLD);
        nameView.setGravity(Gravity.CENTER);
        root.addView(nameView, lp(-1, 42));

        TextView usernameView =
                makeText("@" + username, 15, gray);
        usernameView.setGravity(Gravity.CENTER);
        root.addView(usernameView, lp(-1, 28));

        TextView bioView = makeText(bio, 14, dark);
        bioView.setGravity(Gravity.CENTER);
        bioView.setPadding(dp(5), dp(8), dp(5), dp(15));
        root.addView(bioView, lp(-1, -2));

        // Follow button
        Button follow = new Button(this);
        follow.setText("Follow");
        follow.setTextColor(Color.WHITE);
        follow.setAllCaps(false);
        follow.setBackgroundTintList(
                ColorStateList.valueOf(primary));

        LinearLayout.LayoutParams followParams = lp(165, 48);
        followParams.gravity = Gravity.CENTER_HORIZONTAL;
        root.addView(follow, followParams);

        follow.setOnClickListener(v -> {
            if (follow.getText().toString().equals("Follow")) {
                follow.setText("Following");
            } else {
                follow.setText("Follow");
            }
        });

        // Statistics
        LinearLayout stats = new LinearLayout(this);
        stats.setGravity(Gravity.CENTER);
        stats.setPadding(0, dp(24), 0, dp(22));

        String[] values = {"205", "205K", "870"};
        String[] labels = {"Posts", "Followers", "Following"};

        for (int i = 0; i < values.length; i++) {
            LinearLayout item = vertical();
            item.setGravity(Gravity.CENTER);

            TextView number = makeText(values[i], 23, dark);
            number.setTypeface(null, Typeface.BOLD);
            number.setGravity(Gravity.CENTER);
            item.addView(number, lp(-1, 36));

            TextView label = makeText(labels[i], 13, gray);
            label.setGravity(Gravity.CENTER);
            item.addView(label, lp(-1, 28));

            stats.addView(item,
                    new LinearLayout.LayoutParams(0, -2, 1));
        }
        root.addView(stats);

        // Followers
        TextView followersTitle =
                makeText("Followers", 18, Color.BLACK);
        followersTitle.setTypeface(null, Typeface.BOLD);
        root.addView(followersTitle, lp(-1, 40));

        LinearLayout followers = new LinearLayout(this);
        followers.setGravity(Gravity.CENTER);

        String[] initials = {"AM", "JS", "MK", "LN", "DR"};

        for (int i = 0; i < initials.length; i++) {
            LinearLayout item = vertical();
            item.setGravity(Gravity.CENTER);

            ImageView photo = new ImageView(this);
            photo.setImageResource(
                    i % 2 == 0
                            ? R.drawable.profile_photo
                            : R.drawable.bg_login);
            photo.setScaleType(ImageView.ScaleType.CENTER_CROP);
            photo.setBackground(ovalBackground(
                    Color.rgb(145, 150, 171)));
            photo.setClipToOutline(true);

            LinearLayout.LayoutParams photoParams = lp(43, 43);
            item.addView(photo, photoParams);

            TextView label = makeText(initials[i], 10, gray);
            label.setGravity(Gravity.CENTER);
            item.addView(label, lp(-1, 22));

            followers.addView(item,
                    new LinearLayout.LayoutParams(0, -2, 1));
        }

        root.addView(followers, lp(-1, 70));

        // Posts gallery
        TextView postsTitle = makeText("Posts", 18, Color.BLACK);
        postsTitle.setTypeface(null, Typeface.BOLD);

        LinearLayout.LayoutParams postsTitleParams = lp(-1, 42);
        postsTitleParams.topMargin = dp(8);
        root.addView(postsTitle, postsTitleParams);

        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(3);

        int[] pictures = {
                R.drawable.bg_login,
                R.drawable.profile_photo,
                R.drawable.bg_login,
                R.drawable.profile_photo,
                R.drawable.bg_login,
                R.drawable.profile_photo
        };

        for (int picture : pictures) {
            ImageView post = new ImageView(this);
            post.setImageResource(picture);
            post.setScaleType(ImageView.ScaleType.CENTER_CROP);

            GridLayout.LayoutParams postParams =
                    new GridLayout.LayoutParams();
            postParams.width = 0;
            postParams.height = dp(125);
            postParams.columnSpec =
                    GridLayout.spec(GridLayout.UNDEFINED, 1f);
            postParams.setMargins(dp(2), dp(2), dp(2), dp(2));

            grid.addView(post, postParams);
        }

        root.addView(grid, lp(-1, -2));
        setContentView(scroll);
    }

    void openEdit() {
        Intent intent =
                new Intent(MainActivity.this, com.april.profilapp.EditProfileActivity.class);

        intent.putExtra("name", name);
        intent.putExtra("username", username);
        intent.putExtra("bio", bio);
        intent.putExtra("contact", contact);
        intent.putExtra("country", country);

        startActivityForResult(intent, 100);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode,
                                    Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 100 &&
                resultCode == RESULT_OK && data != null) {

            name = data.getStringExtra("name");
            username = data.getStringExtra("username");
            bio = data.getStringExtra("bio");
            contact = data.getStringExtra("contact");
            country = data.getStringExtra("country");

            showProfile();
        }
    }
}
